#!/usr/bin/env python

from setuptools import setup
setup(
    name='vector',
    version='1.0',
    description='self made 2D-vector calculation',
    author='Sam',
    author_email='1078820859@qq.com',
    url='1078820859@qq.com',
    py_modules=['2D_vector'],
)
    